
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Shield, User, ChevronDown } from 'lucide-react';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">InsureWise</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link to="/" className="text-gray-700 hover:text-blue-600 transition-colors">
              Home
            </Link>
            <div className="relative">
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="flex items-center text-gray-700 hover:text-blue-600 transition-colors"
              >
                Insurance
                <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              {isDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-md shadow-lg py-2">
                  <Link to="/health-insurance" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    Health Insurance
                  </Link>
                  <Link to="/life-insurance" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    Life Insurance
                  </Link>
                  <Link to="/vehicle-insurance" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    Vehicle Insurance
                  </Link>
                  <Link to="/property-insurance" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                    Property Insurance
                  </Link>
                </div>
              )}
            </div>
            <Link to="/compare" className="text-gray-700 hover:text-blue-600 transition-colors">
              Compare
            </Link>
            <Link to="/advisers" className="text-gray-700 hover:text-blue-600 transition-colors">
              Advisers
            </Link>
            <Link to="/advice" className="text-gray-700 hover:text-blue-600 transition-colors">
              Advice Center
            </Link>
          </nav>

          {/* Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Link to="/login" className="text-gray-700 hover:text-blue-600 transition-colors">
              Login
            </Link>
            <Link to="/register" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
              Get Started
            </Link>
            <Link to="/dashboard" className="p-2 text-gray-700 hover:text-blue-600 transition-colors">
              <User className="h-5 w-5" />
            </Link>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-gray-700"
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t">
            <div className="flex flex-col space-y-4">
              <Link to="/" className="text-gray-700 hover:text-blue-600 transition-colors">
                Home
              </Link>
              <Link to="/insurances" className="text-gray-700 hover:text-blue-600 transition-colors">
                Insurance
              </Link>
              <Link to="/compare" className="text-gray-700 hover:text-blue-600 transition-colors">
                Compare
              </Link>
              <Link to="/advisers" className="text-gray-700 hover:text-blue-600 transition-colors">
                Advisers
              </Link>
              <Link to="/advice" className="text-gray-700 hover:text-blue-600 transition-colors">
                Advice Center
              </Link>
              <div className="flex space-x-4 pt-4 border-t">
                <Link to="/login" className="text-gray-700 hover:text-blue-600 transition-colors">
                  Login
                </Link>
                <Link to="/register" className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                  Get Started
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
