
import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Phone, Mail, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <Shield className="h-8 w-8 text-blue-400" />
              <span className="text-xl font-bold">InsureWise</span>
            </Link>
            <p className="text-gray-400 mb-6">
              Your trusted partner in finding the perfect insurance coverage. 
              Expert advice, smart comparisons, and personalized solutions.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-400 hover:text-white transition-colors">Home</Link></li>
              <li><Link to="/about" className="text-gray-400 hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/insurances" className="text-gray-400 hover:text-white transition-colors">Insurance</Link></li>
              <li><Link to="/compare" className="text-gray-400 hover:text-white transition-colors">Compare Policies</Link></li>
              <li><Link to="/advisers" className="text-gray-400 hover:text-white transition-colors">Find Advisers</Link></li>
              <li><Link to="/advice" className="text-gray-400 hover:text-white transition-colors">Advice Center</Link></li>
            </ul>
          </div>

          {/* Insurance Types */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Insurance Types</h3>
            <ul className="space-y-2">
              <li><Link to="/health-insurance" className="text-gray-400 hover:text-white transition-colors">Health Insurance</Link></li>
              <li><Link to="/life-insurance" className="text-gray-400 hover:text-white transition-colors">Life Insurance</Link></li>
              <li><Link to="/vehicle-insurance" className="text-gray-400 hover:text-white transition-colors">Vehicle Insurance</Link></li>
              <li><Link to="/property-insurance" className="text-gray-400 hover:text-white transition-colors">Property Insurance</Link></li>
              <li><Link to="/business-insurance" className="text-gray-400 hover:text-white transition-colors">Business Insurance</Link></li>
              <li><Link to="/travel-insurance" className="text-gray-400 hover:text-white transition-colors">Travel Insurance</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-blue-400" />
                <span className="text-gray-400">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-blue-400" />
                <span className="text-gray-400">info@insurewise.com</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="h-5 w-5 text-blue-400" />
                <span className="text-gray-400">123 Insurance St, City, State 12345</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              © 2024 InsureWise. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link to="/privacy" className="text-gray-400 hover:text-white text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link to="/terms" className="text-gray-400 hover:text-white text-sm transition-colors">
                Terms of Service
              </Link>
              <Link to="/cookies" className="text-gray-400 hover:text-white text-sm transition-colors">
                Cookie Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
